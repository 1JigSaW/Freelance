# Найти сумму элементов массива

arr = [1, 2, 4, 5]

summ = 0
for i in arr:
	summ += i
print(summ)