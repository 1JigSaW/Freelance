# Найти произведение элементов массива

arr = [1, 2, 4, 5]

mult = 1
for i in arr:
	mult *= i
print(mult)